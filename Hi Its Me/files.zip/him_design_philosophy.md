# Late Signal
### Design Philosophy — H.I.M. (Hi, It's Me)

---

## The Movement

*Late Signal* is a design philosophy built around the warmth of digital presence — the specific intimacy of knowing someone is there. It lives in the space between midnight and morning, in the glow of a screen in an otherwise dark room. This is not nostalgia for technology. It is reverence for what technology once made possible: the quiet electricity of a name appearing in your list.

## Form and Light

Space is treated as atmosphere. Deep indigo-black fields hold everything, not as void but as depth — the way a dark room gives meaning to a single lit window. Form emerges from light, not the other way around. The speech bubble is not a UI element; it is a luminous object, a warm vessel floating in ink. Every shape earns its presence by carrying heat. The amber gradient inside is not decoration — it is material, the color of fire held in glass, crafted with the patience of someone who spent hours calibrating each stop.

## Color as Warmth Signal

The palette is built around one emotional truth: amber against deep indigo reads as *someone is home*. Amber is not yellow. It is older — ember, candlelight, the icon status dot that meant a real person was on the other end. Lavender lives in the periphery as atmospheric counterpoint, a bruise-blue that makes the amber feel warmer by contrast. Cream is reserved for the most intimate marks. Nothing competes with the signal. The palette was assembled with the exactness of a master colorist who spent days rejecting dozens of values to find the ones that coexist without argument.

## Type as Intimacy

Instrument Serif carries the identity. Its weight is considered — not decorative, not functional, somewhere in between. The wordmark is lowercase: `him.` The period is intentional. Complete thought. Definitive arrival. The period is amber. In body context, Instrument Serif Italic handles the tagline — a breath, a lean into the ear. DM Mono handles the operational layer: screen names, away messages, status strings. The system has exactly three voices and they do not overlap. The kerning, leading, and tracking in this system reflect the painstaking calibration of a typographer who understands that two pixels of tracking is a different feeling than three.

## Composition and Ritual

Layouts favor restraint with intent. A thin amber rule divides without declaring. Labels float above their content like section headers in a reference manual from an imaginary discipline — one that studies friendship the way astronomers study light. The presence indicator (the dot) is the smallest, most critical element in the system. Its three states — online, away, offline — hold the entire emotional range of the product. The dot is not an accessory. It is the thesis. Every other element exists to surround it with the right amount of silence.

---

*Fonts: Instrument Serif, Instrument Sans, DM Mono*  
*Primary accent: #FFA248 Signal Amber*  
*Foundation: #0A0616 Ink*
